# Terraform AWS Infrastructure

## Project Overview
This project demonstrates Infrastructure as Code (IaC) using Terraform to provision an Amazon EC2 instance.

## Technologies Used
- Terraform
- AWS
- Amazon EC2
- Infrastructure as Code (IaC)

## Project Structure
- `provider.tf` - Terraform and AWS provider configuration
- `main.tf` - EC2 infrastructure
- `variables.tf` - Input variables
- `outputs.tf` - Output values
- `.gitignore` - Files that should not be committed

## Terraform Commands
```bash
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply
terraform destroy
```

## Security
Do not commit AWS access keys, secret keys, passwords, or other credentials to GitHub.

## Author
Polnati Sai Narasimha Naidu
